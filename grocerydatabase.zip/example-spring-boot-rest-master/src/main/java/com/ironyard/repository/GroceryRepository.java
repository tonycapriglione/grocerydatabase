package com.ironyard.repository;

import com.ironyard.springboot.data.GroceryItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GroceryRepository extends JpaRepository<GroceryItem, Integer> {
}
