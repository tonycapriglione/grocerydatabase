package com.ironyard.springboot.data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="list")
public class GroceryItem {
	
	@Id
	@GeneratedValue
	private int id;
	
	private String name;
	private String isle;
	private double price;
	private long quantity;
	
	
	public String getName() {
		return name;
	}
	public int getID() {
		return id;
	}
	public void setID(int id) {
		this.id = id;
	}
	public String getIsle() {
		return isle;
	}
	public void setIsle(String isle) {
		this.isle = isle;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public long getQuantity() {
		return quantity;
	}
	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
