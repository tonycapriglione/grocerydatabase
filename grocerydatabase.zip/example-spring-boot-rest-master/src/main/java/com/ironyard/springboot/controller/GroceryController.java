package com.ironyard.springboot.controller;
import com.ironyard.repository.GroceryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.Collection;
import java.util.HashMap;


import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ironyard.springboot.data.GroceryItem;

@RestController
public class GroceryController {
	
	@Autowired
    private GroceryRepository groceryRepository;
	
//	private HashMap<Integer, GroceryItem> tempStore = new HashMap<Integer, GroceryItem>();
	
	/**
	 * Create the specified GroceryItem
	 * @param createThis
	 * @return populated GroceryItem
	 */
	@RequestMapping(value = "/groceryitems", method = RequestMethod.POST)
	public GroceryItem create(@RequestBody GroceryItem createThis){
		// store it
//		System.out.print("the value is:"+ createThis.getID());
//		tempStore.put(createThis.getID(), createThis);
		groceryRepository.save(createThis);
		return createThis;
	} 
	
	/**@RequestMapping(value = "/groceryitems", method = RequestMethod.PATCH)
	public GroceryItem update(@RequestBody GroceryItem updateThis){
		// store it
//		tempStore.remove(updateThis.getID());
//		tempStore.put(updateThis.getID(), updateThis);
		groceryRepository.save(updateThis);
		return updateThis;
	}*/
	
	/**
	 * Get the specified GroceryItem
	 * @param id
	 * @return requested GroceryItem
	 */
	@RequestMapping(value = "/groceryitems/{id}", method = RequestMethod.GET)
	public GroceryItem get(@PathVariable Integer id){
		// set ID
//		return tempStore.get(name);
		return groceryRepository.findOne(id);
	}
	
	
	/**
	 * 
	 * @return Collection of all GroceryItems
	 */
	@RequestMapping(value = "/groceryitems", method = RequestMethod.GET)
	public Collection<GroceryItem> get() {
		// set ID
//		return tempStore.values();
		return groceryRepository.findAll();
	}
	
	/**
	 * Deletes the specified GroceryItem
	 * @param createThis
	 * @return "Deleted Succesfully"
	 */
	@RequestMapping(value = "/groceryitems", method = RequestMethod.DELETE)
	public String delete(@RequestBody GroceryItem deleteThis){
//		tempStore.remove(deleteThis.getName());
		groceryRepository.delete(deleteThis);
		return "Deleted Successfully";
	}
}


